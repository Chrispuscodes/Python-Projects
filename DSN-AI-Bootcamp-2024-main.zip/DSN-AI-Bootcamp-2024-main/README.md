# DSN-AI-Bootcamp-2024
Starter Notebook for Learners to participate in the bootcamp
